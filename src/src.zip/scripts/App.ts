import { Sheet } from "./Sheet.js";
import { IToolInfo, Tool } from "./Tool.js";
import { Line } from "./Tools/Line.js";

export class App
{
    _sheet:Sheet;
    _tools:typeof Tool[];

    constructor()
    {
        debugger;
        this._sheet = new Sheet();
        this._tools = [];   
        //registration
        this.RegisterTool(Line);
    }

    RegisterTool(c:typeof Tool): void
    {
        let name:IToolInfo = c.GetToolInfo();
        this._tools.push(c);

        this.SetCurrentTool(this._tools[0]);
    }

    private SetCurrentTool(c: typeof Tool):void 
    {
        let t:Tool = new c(this._sheet);
        this._sheet.SetTool(t);
    }
}