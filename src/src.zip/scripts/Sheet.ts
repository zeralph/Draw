import {Tool} from "./Tool.js"
import {Mouse} from "./Mouse.js"

export class Sheet
{
	private _canvas:HTMLCanvasElement = null;
	private _context = null;
	private _lastTime = 0;
	private _curTool:Tool = null;
	private _mouse:Mouse;
	
	constructor()
	{
		this._canvas = document.getElementById("sheet") as HTMLCanvasElement;
		this._context = this._canvas.getContext("2d");
	
		this._mouse = new Mouse(this._canvas);
	
		window.requestAnimationFrame(this.drawFrame.bind(this));
	}

	GetCanvas():HTMLCanvasElement
	{
		return this._canvas;
	}

	clearCanvas(): void
	{
		this._context.clearRect(0, 0, this._canvas.width, this._canvas.height);
	}
	SetTool(t:Tool):void
	{
		this._curTool = t;
	}
	ReleaseTool():void
	{
		if(this._curTool)
		{
			//save ?
			this._curTool = null;
		}
	}
	updateMousePointer(): void
	{
		this._context.fillStyle = "#000000";
		let d:Mouse.MouseData = this._mouse.getMouseData();
		this._context.fillRect (d._x, d._y, 10, 10);
	}
	
	drawFrame(timeStamp):void
	{
		if (this._lastTime == 0) {
			this._lastTime = timeStamp;
		}
		const elapsed = timeStamp - this._lastTime;
		this.clearCanvas();
		if(this._curTool)
		{
			this._curTool.OnMouseUpdate(this._mouse);
			this._curTool.OnUpdate();
			this._curTool.OnDrawGizmos();
		}
		this.updateMousePointer();
		window.requestAnimationFrame(this.drawFrame.bind(this))
	}
}