export class Mouse {


    private pageX:number;
    private pageY:number;
    private canvasX:number;
    private canvasY:number;
    private status:Mouse.MouseStatus;
    private canvas:HTMLCanvasElement;
    private gridSize: number = 10;

    constructor(c:HTMLCanvasElement)
    {
        this.canvas = c;
        document.addEventListener('mousemove', this.onMouseUpdate.bind(this), false);
        document.addEventListener("mousedown", this.onMouseDown.bind(this), false);
        document.addEventListener("mouseup", this.onMouseDown.bind(this), false);
        document.addEventListener("click", this.onMouseClick.bind(this), false);
        this.status = Mouse.MouseStatus.None;
    }

    setGridSize(s:number): void
    {
        this.gridSize = s;

    }

    getGridSize():number
    {
        return this.gridSize;
    }

    getMouseData():Mouse.MouseData
    {
        return {
            _x:this.canvasX,
            _y:this.canvasY,
            _status:this.status
        };
    }

    getMousePositionInCanvas():void 
    {
        let rect = this.canvas.getBoundingClientRect();
        let x:number = Math.floor((this.pageX - rect.left) / (rect.right - rect.left) * this.canvas.width);
        let y:number = Math.floor((this.pageY - rect.top) / (rect.bottom - rect.top) * this.canvas.height);
        this.canvasX = Math.floor(x / this.gridSize) * this.gridSize;
        this.canvasY = Math.floor(y / this.gridSize) * this.gridSize;
    }

    onMouseUpdate(e):void
    {
        this.pageX = e.pageX;
        this.pageY = e.pageY;
        this.getMousePositionInCanvas();
    }
    
    onMouseClick(e):void
    {
        this.status = Mouse.MouseStatus.Clicked;
    }
    
    onMouseDown(e):void
    {
        this.status = Mouse.MouseStatus.Pressed;
    }
    
   onMouseUp(e):void
    {
        this.status = Mouse.MouseStatus.Released;
    }
    

}

export namespace Mouse {
    export enum MouseStatus {
        None=0,
        Pressed=1,
        Released=2,
        Clicked=3,
    }

    export interface MouseData {
        _x:number;
        _y:number;
        _status:Mouse.MouseStatus;
    }
}