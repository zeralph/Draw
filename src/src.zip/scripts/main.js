const f = '\
<html lang="en">\
	<head>\
		<meta charset="UTF-8">\
		<title>draw</title>\
		<link rel="stylesheet" href="draw.css">\
		<script type="module">\
            import { Sheet } from "data/Sheet.js"\
            let sheet = new Sheet(); \
        </script>\
	</head>\
	<body>	\
		<div id="app" class="app-container">\
			<canvas id="sheet" class="sheet" width="480px" height="640px">\
			</canvas>\
		</div>\
	</body>\
</html>\
';

const http = require("http");
const hostname = "localhost";
const port = 3000;
const server = http.createServer((req, res) => {
 console.log(req.headers);
 res.statusCode = 200;
 //res.end("<html><body><h1>Hello, World!</h1></body></html>");
 res.end(f);
})
server.listen(port, hostname);